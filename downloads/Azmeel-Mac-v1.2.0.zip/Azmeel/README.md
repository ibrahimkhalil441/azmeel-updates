# Azmeel by Bu Khalil Studio — v1.2.0

**إزميل** بلاجن لـ Adobe Illustrator بتحوّل أي صورة لـ **Vector**: Engraving، وHalftone، وحبيبات Film grain،
وستايل **Mist** (حبيبات ناعمة زي الـ Airbrush بتدوب في الورقة)، و**Stitch** (باترون كروشيه/كروس ستيتش/Pixel)،
وشعارات بورتريه عليها اسم البراند.
كل الشغل بيطلع Paths حقيقية تقدر تعدّلها.

© 2026 Bu Khalil Studio (Ibrahim Khalil). جميع الحقوق محفوظة. شوف [LICENSE.txt](LICENSE.txt).
English quick guide: [INSTALL.txt](INSTALL.txt).

## التسطيب

البلاجن شغالة على **Illustrator 2019 أو أحدث**، على Windows وMac. نفس الـ ZIP فيه الاتنين.

### Windows
1. فك ضغط `Azmeel-v1.1.4.zip` في أي فولدر (كليك يمين ← Extract All). ما تشغلش التسطيب من جوه الـ ZIP.
2. دبل كليك على `install.bat`.
   - بينسخ البلاجن لـ `%APPDATA%\Adobe\CEP\extensions\com.bukhalil.azmeel`
   - بيفعّل `PlayerDebugMode` عشان Illustrator يقبل يحمّل البانل.
3. اقفل Illustrator وافتحه تاني، وافتح **Window → Extensions → Azmeel**.

> لو ويندوز طلّع تحذير SmartScreen: دوس More info وبعدين Run anyway.

### Mac
1. فك ضغط `Azmeel-v1.1.4.zip` (دبل كليك على الـ ZIP).
2. افتح **Terminal** (Applications ← Utilities ← Terminal)، واكتب `bash` وبعدها مسافة، واسحب ملف `install.command` من فولدر Azmeel جوه نافذة الـ Terminal، ودوس Return.
   الطريقة دي شغالة على كل نسخ macOS ومن غير أي تحذيرات أمان.
   - أو دبل كليك على `install.command`. لو الماك منعه: افتح **System Settings ← Privacy & Security**، وانزل تحت ودوس **Open Anyway**. (في macOS 14 وأقدم ينفع كمان كليك يمين ← Open ← Open.)
   - بينسخ البلاجن لـ `~/Library/Application Support/Adobe/CEP/extensions/com.bukhalil.azmeel`
   - بيفعّل `PlayerDebugMode`.
3. اقفل Illustrator وافتحه تاني، وافتح **Window → Extensions → Azmeel**.

> لو البانل ما ظهرش على الماك: اعمل Log out وادخل تاني (عشان إعداد PlayerDebugMode يتقري)، وبعدين افتح Illustrator.

### أو بملف الـ ZXP (Windows وMac)
لو معاك `Azmeel-v1.1.4.zxp` (نسخة موقّعة):
1. نزّل البرنامج المجاني **ZXP Installer** من aescripts: https://aescripts.com/learn/zxp-installer/
2. افتحه واسحب ملف `Azmeel-v1.1.4.zxp` جواه.
3. اقفل Illustrator وافتحه تاني، وافتح **Window → Extensions → Azmeel**.

لو البانل فتحت فاضية، استخدم `install.bat` أو `install.command` من الـ ZIP بدل كده.

للإزالة: `uninstall.bat` على Windows أو `uninstall.command` على Mac.

## الاستخدام

البلاجن بتشتغل على الصور اللي موجودة في الملف المفتوح، من غير ما ترفع أي صورة:

1. افتح الملف في Illustrator، واختار الوضع من التابات فوق: **Photo | Portrait logo | Logo art**.
2. **اختار الصورة على الـ Artboard** وهتتحمّل في البانل لوحدها.
   أو دوس على كارت الصورة تحت التابات وهتفتح قايمة بكل الصور اللي في الملف، سواء Linked 🔗 أو Embedded.
3. اختار ستايل من صف **Styles**. كل ستايل بيوريك صورتك نفسها بالشكل ده.
4. ظبط الإعدادات. كل مجموعة إعدادات بتتفتح وتتقفل، والـ Preview بيفضل ظاهر فوق وإنت بتنزل.
5. دوس **Create vector**. هتلاقي Layer جديدة اسمها `Engraving` فوق الصورة بالمقاس والمكان بالظبط.

- **Compare** على الـ Preview: اسحب على الصورة عشان تقارن الأصل بالـ Engraving.
- أي رقم جنب الـ slider تقدر تكتبه بإيدك، أو تستخدم الأسهم (مع Shift الخطوة أكبر). ودبل كليك على اسم الإعداد يرجّعه للقيمة الافتراضية.
- لو غيّرت إعدادات الستايل هيظهر **Edited · Reset** عشان ترجع له.
- الصور الـ Linked (JPG/PNG) بتتقري من ملفها مباشرة بأعلى جودة. الصور الـ Embedded بتتصدّر في الخلفية جوه ملفك نفسه، من غير ما يفتح أي مستند جديد (الملف بيتعلّم إن فيه تعديل، بس بيرجع زي ما كان بالظبط).
- زرار التحديد (جنب كارت الصورة) لأي حاجة مش صورة: Vector، جروب، أو كذا عنصر مع بعض. وزرار الفولدر لفتح صورة من الجهاز، و**SVG** للتصدير المباشر.

## الإيفكتات (Pattern)

من مجموعة **Pattern** تختار شكل العلامات. كل الإيفكتات شغالة في الأوضاع التلاتة (Photo وPortrait logo وLogo art):

| Pattern | الشكل |
|---|---|
| Lines / Waves / Rings / Spiral | خطوط Engraving سُمكها بيتبع الإضاءة |
| **Halftone** | نقط حجمها بيتبع الإضاءة، ودايرة أو مربع (Dot shape) |
| **Dot grid** | نقط بنفس الحجم ودرجة الرمادي بتتبع الإضاءة، زي شاشات الـ LED (Grey levels = عدد الدرجات) |
| **Grain** | حبيبات عشوائية كثافتها بتتبع الضل، زي حبيبات الفيلم |
| **Mist** | حبيبات ناعمة جدًا زي الـ Airbrush: التدرّج ناعم، والضل الغامق بيبقى أسود صلب، ونقط منوّرة صغيرة جوه الغامق |
| **Stitch** | الصورة كأنها باترون كروشيه أو كروس ستيتش: مربعات (Pixel) أو نقط أو غُرز ×، بلون واحد أو درجات أو ألوان الصورة، ومعاها خطوط الشبكة |

- **Rough edges** مع الخطوط: بيخلي حواف الخط متعرجة زي الحبر، وده ستايل Ink strokes.
- **Fill background** في Output: بيحط مستطيل لون ورا الشغل. مع **Invert** وحبر أبيض بيطلع نقط بيضا على أسود.

### Mist: حبيبات ناعمة بتدوب في الورقة

أحسن نتيجة مع صورة لحيوان أو شخص على خلفية فاتحة. إعداداته في مجموعة **Pattern** لما تختار Mist:

| الإعداد | بيعمل إيه |
|---|---|
| Grain density | نعومة الحبيبات. كل ما تزيد الحبيبات بتصغر والتدرّج بيبقى أنعم (وعدد النقط بيزيد) |
| Grain size | حجم الحبيبة |
| Ignore light areas | أي درجة أفتح من كده بتبقى ورق أبيض نضيف، والباقي بيتمدّ على كل الدرجات |
| Solid black from | الدرجات الأغمق من كده بتبقى شكل أسود صلب واحد (أخف بكتير من آلاف النقط). 100% = حبيبات بس |
| Spray texture | تكتلات عشوائية زي رشة الـ Airbrush |
| Sparkles | نقط صغيرة بلون الورقة متفرقة جوه المناطق الغامقة |

جوه Illustrator الـ Mist بيطلع جروبات: `Solid` (Compound path)، و`Grain`، و`Sparkle` (نقط بيضا أو بلون الخلفية).

### Stitch: باترون كروشيه / كروس ستيتش / Pixel

الصورة بتتقسم لشبكة مربعات، وكل مربع يا إما حبر يا إما ورق (أو درجة، أو لون من ألوان الصورة). إعداداته في **Pattern** لما تختار Stitch:

| الإعداد | بيعمل إيه |
|---|---|
| Cells across | عدد المربعات على الضلع الطويل |
| Cell shape | **Pixel** مربعات (المتلاصقة بتتدمج في شكل واحد)، **Dot** نقط مدورة، **Cross** غُرز × زي الكروس ستيتش |
| Cell fill | حجم العلامة جوه المربع. 100% مع Pixel = مربعات لازقة في بعض |
| Colors | **Ink** لون واحد، **Shades** كام درجة من لون الحبر، **Image** ألوان الصورة نفسها |
| Threshold | مع Ink: المربعات الأغمق من كده بتتلوّن |
| Number of colors | مع Image: عدد الألوان اللي بتتاخد من الصورة. كل لون بيطلع في جروب لوحده |
| Leave the lightest color empty | مع Image: أفتح لون بيتساب فاضي زي القماش |
| Chart grid lines | خطوط الشبكة فوق المربعات، و**Bold line every** خط تقيل كل كام مربع (زي الباترونات المطبوعة)، و**Grid color** لونها |

الـ Presets: **Stitch chart** (أحمر على أبيض بشبكة)، **Dot pixels** (نقط بيضا على أسود)، **Cross-stitch** (ألوان الصورة بشبكة)،
وفي Portrait logo: **Stitch**، وفي Logo art: **Pixel**.

### Dissolve: الشغل يدوب في الورقة

مجموعة **Dissolve** شغالة مع كل الإيفكتات: **Fade into the paper** بتختار منين الشغل يبدأ يختفي
(من تحت، من فوق، من الشمال، من اليمين، أو من كل الأطراف)، و**Fade length** قد إيه الاختفاء بيدخل جوه الصورة.
الحد بتاع الاختفاء متكسّر وعشوائي عشان يبان طبيعي.

### الـ Presets

- **Photo:** Classic، Banknote، Fine portrait، Woodcut، Rings، Spiral، Halftone، Dot grid، Film grain، Mist، **Stitch chart**، **Dot pixels**، **Cross-stitch**، Ink strokes
- **Portrait logo:** Round badge، Sunburst، Stamp، Woodcut، Glow halftone، Halftone، Mist، **Stitch**، Cut-out
- **Logo art:** Embossed، Bevel، Gradient، Clean lines، Crosshatch، Waves، Halftone، Mist، **Pixel**، Rings

جوه Illustrator النقط بتطلع Compound paths (كل 2000 نقطة في واحد) عشان الملف يفضل خفيف، ودرجات الرمادي في Dot grid كل درجة في جروب لوحدها. في ملفات CMYK الأسود والرمادي بيطلعوا K صافي.

## الأوضاع

فوق في البانل فيه زرار **Photo | Portrait logo | Logo art**:

- **Photo:** سُمك الخط بيتبع النور والظل في الصورة (Engraving للصورة كلها).
- **Portrait logo:** بيحوّل صورة شخص لـ **شعار**، والتفاصيل تحت.
- **Logo art:** بيحفر لوجو موجود أصلاً، والتفاصيل تحت.

## Portrait logo: صورة شخص ← شعار

1. **بيشيل الخلفية ويسيب الشخص بس.** بيشتغل كويس مع الخلفية السادة حتى لو فيها تدرّج، ومع صور PNG الشفافة.
   لو الخلفية زحمة (مكتب، شارع)، شيلها الأول في Photoshop (Remove Background) وحط الـ PNG.
2. **بيبسّط الدرجات لشكل شعار:** ضلال سودا صلبة، خطوط Engraving في الدرجات المتوسطة، وأبيض نضيف في الإضاءة.
3. **بيحط الشخص في إطار:** دايرة أو مربع بحواف مدورة، بحلقة واحدة أو حلقتين. ممكن الراس يطلع بره الإطار،
   وورا الشخص ممكن تحط أشعة (Sunburst) أو خطوط.

| الإعداد | بيعمل إيه |
|---|---|
| Remove background / Background tolerance | إزالة الخلفية. لو جزء من الوش اتشال وطّي الـ tolerance، ولو فضل جزء من الخلفية ارفعها |
| Smooth silhouette | بينعّم حدود الشخص |
| Outline around the person | خط رفيع حوالين الشخص |
| Solid black shadows / Shadows start at | الضلال اللي بتتحول لأسود صلب |
| White highlights below | الإضاءة اللي بتتساب بيضا. وطّيها لو الوش باهت |
| Frame / Frame size / X / Y | شكل الإطار وحجمه ومكانه |
| Ring weight / Double ring | سُمك الحلقة، وحلقة تانية رفيعة جوه |
| Head breaks out of the frame | الراس يطلع فوق الحلقة |
| Behind the person | فاضي، أشعة، أو خطوط |

Presets: Round badge، Sunburst، Stamp، Woodcut، Glow halftone، Halftone، Mist، Stitch، Cut-out (من غير إطار).

جوه Illustrator الشعار بيطلع Layer فيها جروبات منفصلة:
`Shadows` (Compound path)، `Engraving`، `Backdrop`، `Silhouette`، `Frame`، `Frame inner`.
كده تقدر تعدّل أي جزء لوحده أو تضيف اسم البراند.

### اسم البراند حوالين الدايرة

في وضع Portrait logo وإطار **Circle** هتلاقي مجموعة **Brand text**:

- **Top text / Bottom text:** نص فوق الدايرة (بيتقري برا) ونص تحتها (معدول). ينفع عربي أو إنجليزي.
- **Font / Style:** كل الخطوط اللي Illustrator شايفها: خطوط الجهاز، وكل **Adobe Fonts** اللي مفعّلها من fonts.adobe.com.
  - فيه بحث، وفلتر **All / Adobe Fonts / System**، وجنب كل خط عدد الـ Styles بتاعته.
  - علامة **Adobe** بلون كامل = خط Adobe Fonts شغال في كل البرامج. علامة **Adobe** بإطار بس = مفعّل لبرامج Adobe بس.
  - الخطوط اللي من النوع التاني المتصفح اللي جوه البانل مش بيقدر يرسمها، فالبلاجن بيطلب شكل الكلام من Illustrator نفسه ويعرضه في الـ Preview بالظبط. بياخد حوالي ثانية بعد ما توقف كتابة، ومن غير ما يفتح أي مستند جديد.
  - فعّلت خط جديد وإنت فاتح البانل؟ دوس زرار ↻ في قايمة الخطوط.
- **Text size / Letter spacing:** حجم الكلام والمسافة بين الحروف. النص العربي بيتحط من غير مسافات عشان الحروف تفضل متصلة.
- **Dots between the texts:** نقطتين على الجنبين بين النصين.
- **Convert text to outlines:** لو مقفول (الافتراضي)، الكلام بيطلع **نص حقيقي على Path تقدر تعدّله** في Illustrator. لو مفتوح، بيتحول لأشكال.

البلاجن بيعمل مساحة للكلام بين الحلقة الخارجية والداخلية. لو النص طويل بيصغر لوحده عشان يدخل في نص الدايرة، وجوه Illustrator بيتأكد إن مفيش حرف اتقص.

> لما تكتب نص فوق و**Head breaks out of the frame** شغال، البلاجن بيقفله ويطلّع الإطار لفوق عشان الراس ما تغطيش الكلام. تقدر ترجّعه من Badge.

## Logo art: حفر لوجو موجود

- البلاجن بيفصل اللوجو عن الخلفية (بأي لون، على خلفية سادة أو شفافة)، والخطوط بتتقص
  **بالظبط** عند حدود الشكل. التظليل بيبقى صناعي عشان يدي إحساس الحفر:


| Shading | الشكل |
|---|---|
| Emboss | بارز ثلاثي الأبعاد، الجوانب اللي ناحية النور خطوطها رفيعة (اتجاه النور من *Light direction*) |
| Bevel | خطوط تقيلة عند الحواف وبتخف ناحية النص |
| Gradient | تدرّج على اللوجو كله |
| Flat lines | خطوط منتظمة وبس |
| Follow logo colors | لو اللوجو فيه أكتر من لون، كل لون بيطلع بدرجة مختلفة |

إعدادات إضافية في وضع اللوجو: **Outline** (خط حوالين الشكل، بيطلع Stroke حقيقي)، و**Gap before edge**
(مسافة بين الخطوط والـ Outline)، و**Background tolerance** (لو جزء من اللوجو مش ظاهر ارفعها)،
و**Engrave the background instead** (يحفر الخلفية ويسيب اللوجو فاضي).

في Presets خاصة باللوجو: Embossed، Bevel، Gradient، Clean lines، Crosshatch، Waves، Rings.

> في وضع اللوجو، عدد الخطوط بيتحسب على حجم اللوجو نفسه مش الصورة كلها، فالمساحة الفاضية حوالين اللوجو مش بتأثر.

## الإعدادات

| الإعداد | بيعمل إيه |
|---|---|
| Style | خطوط مستقيمة، Waves، دواير متداخلة، أو Spiral |
| Line count | عدد الخطوط. كل ما يزيد التفاصيل بتبقى أنعم |
| Max thickness | أقصى سُمك للخط في المناطق السودا (نسبة من المسافة بين الخطوط) |
| Min thickness | أي جزء أرفع من كده بيتشال، وده اللي بيعمل الفراغات في الـ highlights |
| Angle | زاوية الخطوط |
| Relief | قد إيه الخطوط بتنحني مع الإضاءة، وده اللي بيدي الإحساس بالعمق |
| Crosshatch | طبقة خطوط تانية بزاوية مختلفة تظهر في المناطق الغامقة بس |
| Brightness / Contrast / Gamma | ضبط درجات الصورة قبل التحويل |
| Smooth image | بيشيل النويز والتفاصيل الصغيرة |
| Simplify paths | بيقلل عدد الـ anchor points |
| Ink color | لون الخطوط. الأسود في ملف CMYK بيطلع K=100 صافي |

اكتب أي رقم بإيدك أو استخدم الأسهم، ودبل كليك على اسم الإعداد يرجّعه للقيمة الافتراضية. زرار **Compare** على الـ Preview بيقارن بالصورة الأصلية.

## التحديثات (من غير تسطيب تاني)

من النسخة دي (Azmeel 1.2 و Azmeel Pro 2.3) البلاجن بتحدّث نفسها:
- لما تفتح البانل بتشوف لوحدها لو فيه نسخة جديدة (مرة كل 6 ساعات بالكتير)، ولو فيه بيظهر شريط تحت: **"… is available"**.
- دوس **Update**: بتنزّل الملفات الجديدة وتبدّلها، والبانل بتفتح تاني بالنسخة الجديدة. إعداداتك واستايلاتك زي ما هي.
- **Later** بيقفل الشريط، وهيظهر تاني المرة الجاية.
- تقدر تشيّك بنفسك من شاشة About ← **Check for updates**.

الأمان: كل تحديث متوقّع من Bu Khalil Studio، والبلاجن بتتأكد من التوقيع ومن كل ملف قبل ما تكتب أي حاجة. لو ملف واحد مش مطابق، مفيش حاجة بتتغيّر.

لو البلاجن متسطّبة لكل المستخدمين (بملف ZXP في فولدر النظام)، مش هتقدر تبدّل ملفاتها. ساعتها الشريط بيقول كده، وزرار **Download** بيفتح صفحة التحميل عشان تسطّب النسخة الجديدة بالطريقة العادية.

## About

زرار **ⓘ** جنب الشعار فوق بيفتح شاشة About، وفيها:
- اسم البلاجن ورقم النسخة، وزرار **Check for updates**.
- معلومات عن **Bu Khalil Studio**.
- لينكات Behance وInstagram وLinkedIn. بتفتح في المتصفح بتاعك، مش جوه Illustrator.
- حقوق الملكية.

---

**Azmeel by Bu Khalil Studio** · © 2026 Bu Khalil Studio (Ibrahim Khalil). All rights reserved.
[Behance](https://www.behance.net/Ibrahimkhalil50) · [Instagram](https://www.instagram.com/bu.khalil.studio) · [LinkedIn](https://www.linkedin.com/in/ibrahim-khalil-50th/)
