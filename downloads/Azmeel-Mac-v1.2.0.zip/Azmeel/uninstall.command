#!/bin/bash
# Azmeel by Bu Khalil Studio - macOS uninstaller.
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
rm -rf "$EXT/com.bukhalil.azmeel" "$EXT/com.boukhalil.engraver" "$EXT/com.comrc.engraver"
echo "Azmeel removed. Restart Illustrator."
echo
read -r -n 1 -s -p "Press any key to close..."
echo
