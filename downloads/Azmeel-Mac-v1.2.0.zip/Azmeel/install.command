#!/bin/bash
# Azmeel by Bu Khalil Studio - macOS installer.
# Copyright (c) 2026 Bu Khalil Studio (Ibrahim Khalil). All rights reserved.
# Easiest on every macOS version: in Terminal type "bash " and drag this file in, then Return.
# Or double-click it; if macOS blocks it: System Settings > Privacy & Security > Open Anyway.

cd "$(dirname "$0")" || exit 1
SRC="$PWD/com.bukhalil.azmeel"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXT/com.bukhalil.azmeel"

pause_exit() { echo; read -r -n 1 -s -p "Press any key to close..."; echo; exit "$1"; }

echo "Installing Azmeel by Bu Khalil Studio for Adobe Illustrator..."

# Check the plugin files first, so a failed run never removes a working install.
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo
  echo "Plugin files not found next to install.command."
  echo "Unzip the whole package first, then run install.command from that folder."
  pause_exit 1
fi

mkdir -p "$EXT" || { echo "Could not create $EXT"; pause_exit 1; }
# Remove this version and the plugin's earlier names (Boukhalil, COMRC Engraver).
rm -rf "$DEST" "$EXT/com.boukhalil.engraver" "$EXT/com.comrc.engraver"
cp -R "$SRC" "$DEST" || { echo "Copy failed."; pause_exit 1; }

# Files downloaded from the internet carry a quarantine flag; the panel doesn't need it.
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null

# Unsigned CEP panels only load when PlayerDebugMode is on.
for v in 9 10 11 12 13; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done
# Make sure the new preference is picked up without logging out.
killall -u "$(id -un)" cfprefsd 2>/dev/null

echo
echo "Installed to: $DEST"
echo "Restart Illustrator, then open:  Window > Extensions > Azmeel"
pause_exit 0
