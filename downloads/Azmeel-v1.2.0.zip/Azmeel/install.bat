@echo off
rem Azmeel by Bu Khalil Studio - Windows installer.
rem Copyright (c) 2026 Bu Khalil Studio (Ibrahim Khalil). All rights reserved.
setlocal
set "SRC=%~dp0com.bukhalil.azmeel"
set "EXT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXT%\com.bukhalil.azmeel"

echo Installing Azmeel by Bu Khalil Studio for Adobe Illustrator...

rem Check the plugin files first: running this from inside the ZIP (without extracting)
rem would otherwise delete the old install and then fail to copy.
if not exist "%SRC%\CSXS\manifest.xml" (
  echo.
  echo Plugin files not found next to install.bat.
  echo Extract the whole ZIP to a folder first, then run install.bat from there.
  echo.
  pause
  exit /b 1
)

rem Remove this version and the plugin's earlier names (Boukhalil, COMRC Engraver).
if exist "%DEST%" rmdir /s /q "%DEST%"
if exist "%EXT%\com.boukhalil.engraver" rmdir /s /q "%EXT%\com.boukhalil.engraver"
if exist "%EXT%\com.comrc.engraver" rmdir /s /q "%EXT%\com.comrc.engraver"

xcopy "%SRC%" "%DEST%\" /e /i /y /q >nul
if errorlevel 1 (
  echo Copy failed.
  pause
  exit /b 1
)

rem Unsigned CEP panels only load when PlayerDebugMode is on.
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo.
echo Installed to: %DEST%
echo Restart Illustrator, then open:  Window ^> Extensions ^> Azmeel
echo.
pause
