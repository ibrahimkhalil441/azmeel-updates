@echo off
rem Azmeel by Bu Khalil Studio - Windows uninstaller.
set "EXT=%APPDATA%\Adobe\CEP\extensions"
if exist "%EXT%\com.bukhalil.azmeel" rmdir /s /q "%EXT%\com.bukhalil.azmeel"
if exist "%EXT%\com.boukhalil.engraver" rmdir /s /q "%EXT%\com.boukhalil.engraver"
if exist "%EXT%\com.comrc.engraver" rmdir /s /q "%EXT%\com.comrc.engraver"
echo Azmeel removed. Restart Illustrator.
pause
